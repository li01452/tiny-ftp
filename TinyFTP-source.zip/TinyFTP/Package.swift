// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TinyFTP",
    platforms: [.macOS(.v13)],
    products: [.executable(name: "TinyFTP", targets: ["TinyFTP"])],
    targets: [
        .executableTarget(name: "TinyFTP"),
        .testTarget(name: "TinyFTPTests", dependencies: ["TinyFTP"])
    ]
)
