# 用 GitHub 网页编译 Tiny FTP

全程使用浏览器。无需在 Mac 上安装开发工具。

1. 打开 https://github.com/new ，仓库名称填 `tiny-ftp`。选择 Public（代码和压缩包将公开），勾选 Add a README file，然后点 Create repository。GitHub 的标准 macOS 机器在公开仓库中免费使用。
2. 在新仓库的 Code 页面，点 Add file → Upload files。上传下载到的原始 `TinyFTP-source.zip` 文件，保持文件名不变，不要上传解压后的 TinyFTP 文件夹。上传完成，点 Commit changes 保存。
3. 在 Mac 上解压一份 `TinyFTP-source.zip`，用文本编辑打开里面的 `GitHub-Actions.yml`，复制其全部内容。
4. 回到 GitHub 仓库，点 Add file → Create new file。文件名输入 `.github/workflows/build.yml`，正文粘贴刚才复制的内容，然后点 Commit changes，保存在 main 分支。
5. 点仓库上方 Actions，再点 Build Tiny FTP 的那条运行记录。工作流会自动启动。如果未启动，点左侧 Build Tiny FTP，再点 Run workflow → Run workflow。
6. 等待绿色对勾。打开这次运行的详情页，在下方 Artifacts 区域点击 TinyFTP-macOS-arm64.zip，下载编译结果。解压一次，得到 Tiny FTP.app。
7. 将 Tiny FTP.app 拖进“应用程序”，然后打开。首次联网或访问文件夹时，按系统提示授权。

若 macOS 提示无法验证开发者身份：先尝试打开一次，再到系统设置 → 隐私与安全性，找到该应用的提示，点击“仍要打开”。程序使用临时签名，没有 Apple 开发者签名和公证。不要关闭系统整体安全保护。

若显示红叉：打开失败记录，点击 build，再展开红色步骤，复制错误文字给我。源码此前没有在 macOS 编译过，因此首次云端构建可能需要根据真实编译日志修正。

配置会先运行 Swift 单元测试和本地 FTP 集成测试，再编译和打包。它不会连接你的手机，也不需要任何账号密码或 GitHub Token。下载产物保留 7 天；过期后可重新点击 Run workflow。

后续更新：在 Code 页面重新上传同名 TinyFTP-source.zip 并提交，会自动再次编译。

已有仓库升级到 1.1：需要将 GitHub-Actions.yml 的内容同步到仓库 .github/workflows/build.yml，才会启用新的上传步骤并去掉外层 ZIP。已连接 GitHub 时可直接在修改分支构建，无需手动上传。
