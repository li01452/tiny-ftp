import SwiftUI

@main
@MainActor
struct TinyFTPApp: App {
    var body: some Scene {
        WindowGroup("Tiny FTP") { ContentView() }
            .defaultSize(width: 1060, height: 650)
            .commands { CommandGroup(replacing: .newItem) {} }
    }
}
