import Darwin
import AppKit
import SwiftUI

@MainActor
final class FileManagerViewModel: ObservableObject {
    @Published var address = "ftp://192.168.31.6:2121"
    @Published var remoteEntries: [FileEntry] = []
    @Published var localEntries: [FileEntry] = []
    @Published var remoteSelection: String?
    @Published var localSelection: String?
    @Published private(set) var remotePath: [String] = []
    @Published private(set) var localDirectory = LocalFileService.downloads
    @Published private(set) var connected = false
    @Published private(set) var busy = false
    @Published private(set) var connecting = false
    @Published private(set) var transfer: TransferState?
    @Published var status = "未连接 · 开启手机远程管理后，点击连接"
    @Published var errorMessage: String?

    private let ftp = FTPService()
    private let local = LocalFileService()
    private var endpoint: FTPEndpoint?
    private var token: CurlCancellation?
    private var scopedDirectory: URL?

    init() { refreshLocal() }
    var remoteLocation: String { "/" + remotePath.joined(separator: "/") }
    var selectedRemote: FileEntry? { remoteEntries.first { $0.id == remoteSelection } }
    var selectedLocal: FileEntry? { localEntries.first { $0.id == localSelection } }
    var canUpload: Bool {
        connected && !busy && selectedLocal.map { !$0.isDirectory && !$0.isSymbolicLink } == true
    }
    var canDownload: Bool {
        connected && !busy && selectedRemote.map { !$0.isDirectory && !$0.isSymbolicLink } == true
    }
    var connectionLabel: String { connecting ? "连接中" : (connected ? "已连接" : "未连接") }

    func connect() {
        guard !busy else { return }
        do {
            let target = try FTPEndpoint(address)
            endpoint = target; connected = false; remoteEntries = []; remoteSelection = nil
            loadRemote(target.initialPath, connecting: true)
        } catch { report(error) }
    }
    func refreshRemote() { if connected { loadRemote(remotePath) } else { connect() } }
    func remoteUp() { guard !remotePath.isEmpty else { return }; loadRemote(Array(remotePath.dropLast())) }
    func openRemote(_ entry: FileEntry) {
        guard entry.isDirectory && !entry.isSymbolicLink else { return }
        loadRemote(remotePath + [entry.name])
    }
    private func loadRemote(_ path: [String], connecting isConnection: Bool = false) {
        guard !busy, let endpoint else { return }
        let request = begin(); connecting = isConnection
        status = isConnection ? "正在连接…" : "正在读取远程目录…"
        Task {
            defer { end() }
            do {
                let entries = try await ftp.list(endpoint: endpoint, path: path, token: request)
                try request.check()
                remotePath = path; remoteEntries = entries; remoteSelection = nil
                address = endpoint.url(path: path); connected = true
                status = "已连接 · \(entries.count) 个远程项目"
            } catch is CancellationError { status = "操作已取消" }
            catch {
                // Keep the last successfully listed directory available for retry.
                if isConnection { connected = false }
                report(error)
            }
        }
    }
    func refreshLocal() {
        do {
            localEntries = try local.list(localDirectory)
            if !localEntries.contains(where: { $0.id == localSelection }) { localSelection = nil }
        } catch { report(error) }
    }
    func openLocal(_ entry: FileEntry) {
        guard !busy, entry.isDirectory, !entry.isSymbolicLink else { return }
        navigateLocal(localDirectory.appendingPathComponent(entry.name, isDirectory: true))
    }
    func localUp() {
        guard !busy else { return }
        navigateLocal(localDirectory.deletingLastPathComponent())
    }
    private func navigateLocal(_ url: URL) {
        do {
            let entries = try local.list(url)
            localDirectory = url; localEntries = entries; localSelection = nil
        } catch { report(error) }
    }
    func chooseLocalDirectory() {
        guard !busy else { return }
        let panel = NSOpenPanel()
        panel.title = "选择本地目录"; panel.canChooseFiles = false; panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false; panel.directoryURL = localDirectory
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let granted = url.startAccessingSecurityScopedResource()
        do {
            let entries = try local.list(url)
            scopedDirectory?.stopAccessingSecurityScopedResource()
            scopedDirectory = granted ? url : nil
            localDirectory = url; localEntries = entries; localSelection = nil
        } catch {
            if granted { url.stopAccessingSecurityScopedResource() }
            report(error)
        }
    }

    func upload() {
        guard let entry = selectedLocal else { return }
        upload(entry)
    }
    func upload(_ entry: FileEntry) {
        guard connected, !busy, !entry.isDirectory, !entry.isSymbolicLink,
              localEntries.contains(entry), let endpoint else { return }
        guard FileEntry.validName(entry.name) else { report(FTPError.message("文件名包含不支持的字符。")); return }
        let source = localDirectory.appendingPathComponent(entry.name)
        let path = remotePath
        let request = begin()
        status = "正在检查远程同名文件…"
        Task {
            var startedUpload = false
            defer { end() }
            do {
                let entries = try await ftp.list(endpoint: endpoint, path: path, token: request)
                try request.check(); remoteEntries = entries
                if let existing = entries.first(where: { $0.name == entry.name }) {
                    guard !existing.isDirectory && !existing.isSymbolicLink else {
                        throw FTPError.message("远程存在同名目录或符号链接，不能覆盖。")
                    }
                    guard confirmOverwrite(entry.name, location: "手机 FTP 目录") else {
                        status = "已取消上传"; return
                    }
                }
                let values = try source.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
                guard values.isRegularFile == true, values.isSymbolicLink != true else {
                    throw FTPError.message("请选择一个普通文件上传。")
                }
                try request.check()
                transfer = TransferState(name: entry.name, uploading: true)
                status = "正在上传…"; startedUpload = true
                try await ftp.upload(endpoint: endpoint, path: path, source: source, name: entry.name, token: request) { [weak self] value in
                    Task { @MainActor in self?.transfer?.fraction = value }
                }
                transfer?.fraction = 1
                status = "上传成功：\(entry.name)"
                do { remoteEntries = try await ftp.list(endpoint: endpoint, path: path, token: request) }
                catch { status = "上传已完成，但远程目录刷新失败，请点击刷新。" }
            } catch is CancellationError {
                status = startedUpload ? "上传已取消，手机端可能保留不完整文件" : "操作已取消"
            } catch {
                report(error)
                if startedUpload { status += "；手机端可能保留不完整文件" }
            }
        }
    }

    func download() {
        guard let entry = selectedRemote else { return }
        download(entry)
    }
    func download(_ entry: FileEntry) {
        guard connected, !busy, !entry.isDirectory, !entry.isSymbolicLink,
              remoteEntries.contains(entry), let endpoint else { return }
        let destination = localDirectory.appendingPathComponent(entry.name)
        let hadTarget = LocalFileService.exists(destination)
        if hadTarget {
            guard isReplaceable(destination) else { report(FTPError.message("本地存在同名目录或符号链接，不能覆盖。")); return }
            guard confirmOverwrite(entry.name, location: "本地目录") else { return }
        }
        let directory = localDirectory, path = remotePath
        let temporary = directory.appendingPathComponent(".tinyftp-\(UUID().uuidString).part")
        let request = begin()
        transfer = TransferState(name: entry.name, uploading: false)
        status = "正在下载…"
        Task {
            defer {
                try? FileManager.default.removeItem(at: temporary)
                end()
            }
            do {
                // Exclusive creation avoids truncating an existing file, including through a symlink.
                let descriptor = Darwin.open(temporary.path, O_WRONLY | O_CREAT | O_EXCL, S_IRUSR | S_IWUSR)
                guard descriptor >= 0 else { throw FTPError.message("无法在本地目录创建临时文件，请检查写入权限。") }
                Darwin.close(descriptor)
                try await ftp.download(endpoint: endpoint, path: path, name: entry.name, temporary: temporary, token: request) { [weak self] value in
                    Task { @MainActor in self?.transfer?.fraction = value }
                }
                try request.check()
                if LocalFileService.exists(destination) {
                    guard hadTarget, isReplaceable(destination) else {
                        throw FTPError.message("下载期间出现同名文件或目录，已保留原文件。请重新下载并确认覆盖。")
                    }
                    _ = try FileManager.default.replaceItemAt(destination, withItemAt: temporary)
                } else {
                    try FileManager.default.moveItem(at: temporary, to: destination)
                }
                refreshLocal(); status = "下载成功：\(entry.name)"
            } catch is CancellationError { status = "下载已取消，已有本地文件未改动" }
            catch { report(error) }
        }
    }
    private func isReplaceable(_ url: URL) -> Bool {
        guard let v = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]) else { return false }
        return v.isRegularFile == true && v.isSymbolicLink != true
    }
    private func confirmOverwrite(_ name: String, location: String) -> Bool {
        let alert = NSAlert()
        alert.messageText = "覆盖“\(name)”？"
        alert.informativeText = "\(location)中已有同名文件。覆盖后原文件将被替换。"
        alert.alertStyle = .warning
        alert.addButton(withTitle: "取消")
        alert.addButton(withTitle: "覆盖")
        return alert.runModal() == .alertSecondButtonReturn
    }
    func cancel() { token?.cancel() }
    func shutdown() {
        cancel(); scopedDirectory?.stopAccessingSecurityScopedResource(); scopedDirectory = nil
    }
    private func begin() -> CurlCancellation {
        let value = CurlCancellation(); token = value; busy = true
        return value
    }
    private func end() { token = nil; busy = false; connecting = false; transfer = nil }
    private func report(_ error: Error) {
        let message = error.localizedDescription
        status = message.components(separatedBy: .newlines).first ?? message
        errorMessage = message
    }
}
