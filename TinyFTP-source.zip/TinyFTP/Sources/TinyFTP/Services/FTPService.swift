import Foundation

struct FTPService {
    private let runner = CurlRunner()

    func list(endpoint: FTPEndpoint, path: [String], token: CurlCancellation) async throws -> [FileEntry] {
        let url = endpoint.url(path: path)
        do {
            let data = try await runner.run(["--silent", "--max-time", "30", "--request", "MLSD", "--url", url], token: token)
            do { return try DirectoryParser.parse(data, mlsd: true) }
            catch { /* Some servers accept MLSD but return LIST-formatted data. */ }
        } catch is CancellationError { throw CancellationError() }
        catch let error as CurlFailure {
            // Only unsupported/failed listing commands should fall back.
            guard [8, 19, 21].contains(error.code) else { throw error }
        }
        try token.check()
        let data = try await runner.run(["--silent", "--max-time", "30", "--url", url], token: token)
        return try DirectoryParser.parse(data, mlsd: false)
    }

    func upload(endpoint: FTPEndpoint, path: [String], source: URL, name: String,
                token: CurlCancellation, progress: @escaping @Sendable (Double) -> Void) async throws {
        _ = try await runner.run(["--progress-bar", "--upload-file", source.path,
            "--url", endpoint.url(path: path, file: name)], token: token, progress: progress)
    }

    func download(endpoint: FTPEndpoint, path: [String], name: String, temporary: URL,
                  token: CurlCancellation, progress: @escaping @Sendable (Double) -> Void) async throws {
        _ = try await runner.run(["--progress-bar", "--output", temporary.path,
            "--url", endpoint.url(path: path, file: name)], token: token, progress: progress)
    }
}
