import Foundation

struct LocalFileService {
    func list(_ directory: URL) throws -> [FileEntry] {
        let keys: Set<URLResourceKey> = [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey, .contentModificationDateKey]
        return try FileEntry.sorted(FileManager.default.contentsOfDirectory(at: directory,
            includingPropertiesForKeys: Array(keys), options: [.skipsHiddenFiles]).compactMap { url in
                let value = try url.resourceValues(forKeys: keys)
                guard value.isDirectory == true || value.isRegularFile == true || value.isSymbolicLink == true else { return nil }
                return FileEntry(name: url.lastPathComponent, isDirectory: value.isDirectory == true,
                    size: value.fileSize.map(Int64.init), modified: value.contentModificationDate,
                    isSymbolicLink: value.isSymbolicLink == true)
            })
    }
    static var downloads: URL {
        FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask).first!
    }
    static func exists(_ url: URL) -> Bool {
        (try? FileManager.default.attributesOfItem(atPath: url.path)) != nil
    }
}
