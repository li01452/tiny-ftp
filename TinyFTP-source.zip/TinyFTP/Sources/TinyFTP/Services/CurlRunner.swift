import Foundation

private final class Capture: @unchecked Sendable {
    private let lock = NSLock()
    private var output = Data()
    private var errors = Data()
    private var meter = ""
    private var overflow = false
    private let progress: (@Sendable (Double) -> Void)?

    init(progress: (@Sendable (Double) -> Void)?) { self.progress = progress }

    func append(_ data: Data, stderr: Bool) {
        guard !data.isEmpty else { return }
        lock.lock()
        var values: [Double] = []
        if stderr {
            errors.append(data)
            if errors.count > 131072 { errors.removeFirst(errors.count - 131072) }
            meter += String(decoding: data, as: UTF8.self)
            let pieces = meter.components(separatedBy: CharacterSet.newlines.union(CharacterSet(charactersIn: "\r")))
            meter = pieces.last ?? ""
            for piece in pieces.dropLast() {
                if let range = piece.range(of: #"[0-9]+(?:\.[0-9]+)?%"#, options: .regularExpression),
                   let number = Double(piece[range].dropLast()) {
                    values.append(min(1, max(0, number / 100)))
                }
            }
            if meter.count > 4096 { meter = String(meter.suffix(4096)) }
        } else if output.count + data.count <= 32 * 1024 * 1024 {
            output.append(data)
        } else { overflow = true }
        lock.unlock()
        values.forEach { progress?($0) }
    }
    func result() -> (Data, String, Bool) {
        lock.lock(); defer { lock.unlock() }
        return (output, String(decoding: errors, as: UTF8.self), overflow)
    }
}

struct CurlFailure: LocalizedError {
    let code: Int32
    let details: String
    var errorDescription: String? {
        let reason: String
        switch code {
        case 5, 6: reason = "无法解析服务器地址"
        case 7: reason = "连接失败，请确认手机已开启远程管理，且与 Mac 位于同一局域网"
        case 9, 67: reason = "服务器拒绝匿名访问或目录访问"
        case 18: reason = "传输中断，文件未完整传输"
        case 23: reason = "无法写入本地文件，请检查目录权限和剩余空间"
        case 25: reason = "上传失败，请检查手机是否允许写入及剩余空间"
        case 26: reason = "无法读取本地文件"
        case 28: reason = "连接或传输超时"
        case 78: reason = "远程文件或目录不存在"
        default: reason = "FTP 操作失败（curl \(code)）"
        }
        let lines = details.components(separatedBy: .newlines).filter { $0.contains("curl:") }
        return reason + (lines.last.map { "\n" + $0 } ?? "")
    }
}

struct CurlRunner {
    func run(_ arguments: [String], token: CurlCancellation,
             progress: (@Sendable (Double) -> Void)? = nil) async throws -> Data {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let process = Process()
                process.executableURL = URL(fileURLWithPath: "/usr/bin/curl")
                // Disable .curlrc, shell expansion, proxy inheritance and URL glob expansion.
                // A failed FTP data connection must not hang forever.
                process.arguments = ["--disable", "--globoff", "--noproxy", "*", "--proto", "=ftp",
                    "--user", "anonymous:tinyftp@", "--connect-timeout", "10",
                    "--speed-time", "30", "--speed-limit", "1", "--ftp-pasv",
                    "--ftp-skip-pasv-ip", "--path-as-is", "--show-error",
                    "--quote", "*OPTS UTF8 ON"] + arguments
                var environment = ProcessInfo.processInfo.environment
                environment["LC_ALL"] = "C"
                process.environment = environment
                process.standardInput = FileHandle.nullDevice
                let stdout = Pipe(), stderr = Pipe()
                process.standardOutput = stdout; process.standardError = stderr
                let capture = Capture(progress: progress)
                // Drain both pipes concurrently; a long listing cannot deadlock the child.
                let readers = DispatchGroup()
                do {
                    try token.launch(process)
                    for (pipe, isError) in [(stdout, false), (stderr, true)] {
                        readers.enter()
                        DispatchQueue.global(qos: .utility).async {
                            while true {
                                let data = pipe.fileHandleForReading.availableData
                                if data.isEmpty { break }
                                capture.append(data, stderr: isError)
                            }
                            readers.leave()
                        }
                    }
                    process.waitUntilExit()
                    readers.wait()
                    token.finish()
                    try token.check()
                    let (data, message, overflow) = capture.result()
                    guard process.terminationStatus == 0 else {
                        throw CurlFailure(code: process.terminationStatus, details: message)
                    }
                    if overflow { throw FTPError.message("目录列表超过 32 MB，请进入更小的目录。") }
                    continuation.resume(returning: data)
                } catch {
                    token.finish()
                    continuation.resume(throwing: error)
                }
            }
        }
    }
}
