import Foundation

struct DirectoryParser {
    static func parse(_ data: Data, mlsd: Bool, now: Date = Date()) throws -> [FileEntry] {
        guard let text = String(data: data, encoding: .utf8) else {
            throw FTPError.message("服务器目录列表不是有效 UTF-8，无法安全解析文件名。")
        }
        var entries: [FileEntry] = []
        for raw in text.components(separatedBy: "\n") {
            let line = raw.hasSuffix("\r") ? String(raw.dropLast()) : raw
            if line.isEmpty || (!mlsd && line.hasPrefix("total ")) { continue }
            let entry = mlsd ? parseMLSD(line) : parseLIST(line, now: now)
            if let entry {
                if FileEntry.validName(entry.name) { entries.append(entry) }
                else if entry.name != "." && entry.name != ".." {
                    throw FTPError.message("目录中有不支持的文件名（斜杠或控制字符）。")
                }
            } else if mlsd && (line.lowercased().contains("type=cdir;") || line.lowercased().contains("type=pdir;")) {
                continue
            } else {
                throw FTPError.message("无法识别服务器目录格式，请勿对不完整目录执行覆盖操作。")
            }
        }
        guard Set(entries.map(\.name)).count == entries.count else {
            throw FTPError.message("服务器返回重复文件名，无法安全显示。")
        }
        return FileEntry.sorted(entries)
    }

    private static func parseMLSD(_ line: String) -> FileEntry? {
        guard let split = line.firstIndex(of: " ") else { return nil }
        let name = String(line[line.index(after: split)...])
        var facts: [String: String] = [:]
        for item in line[..<split].split(separator: ";") {
            let pair = item.split(separator: "=", maxSplits: 1)
            if pair.count == 2 { facts[pair[0].lowercased()] = String(pair[1]) }
        }
        guard let type = facts["type"]?.lowercased(), type == "dir" || type == "file" else { return nil }
        var date: Date?
        if let modify = facts["modify"] {
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX")
            f.timeZone = TimeZone(secondsFromGMT: 0)
            f.dateFormat = "yyyyMMddHHmmss"
            date = f.date(from: String(modify.prefix(14)))
        }
        return FileEntry(name: name, isDirectory: type == "dir", size: facts["size"].flatMap(Int64.init), modified: date)
    }

    private static func captures(_ pattern: String, _ line: String) -> [String]? {
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: line, range: NSRange(line.startIndex..., in: line)) else { return nil }
        return (1..<match.numberOfRanges).map { i in
            Range(match.range(at: i), in: line).map { String(line[$0]) } ?? ""
        }
    }

    private static func parseLIST(_ line: String, now: Date) -> FileEntry? {
        // UNIX LIST: preserve all filename spaces after the single separating space.
        if let p = captures(#"^([dl-])[rwxstST-]{9}[+@.]?\s+\d+\s+\S+\s+\S+\s+(\d+)\s+([A-Za-z]{3})\s+(\d{1,2})\s+(\d{2}:\d{2}|\d{4}) (.*)$"#, line) {
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX")
            f.timeZone = .current
            let currentYear = Calendar.current.component(.year, from: now)
            var date: Date?
            if p[4].contains(":") {
                f.dateFormat = "MMM d yyyy HH:mm"
                date = f.date(from: "\(p[2]) \(p[3]) \(currentYear) \(p[4])")
                if let value = date, value.timeIntervalSince(now) > 86400 {
                    date = Calendar.current.date(byAdding: .year, value: -1, to: value)
                }
            } else {
                f.dateFormat = "MMM d yyyy"
                date = f.date(from: "\(p[2]) \(p[3]) \(p[4])")
            }
            let link = p[0] == "l"
            let name = link ? (p[5].components(separatedBy: " -> ").first ?? p[5]) : p[5]
            return FileEntry(name: name, isDirectory: p[0] == "d", size: Int64(p[1]), modified: date, isSymbolicLink: link)
        }
        // Common DOS/IIS LIST format, supported as a conservative fallback.
        if let p = captures(#"^(\d{2}-\d{2}-\d{2,4})\s+(\d{2}:\d{2}[AP]M)\s+(<DIR>|\d+) (.+)$"#, line) {
            let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX")
            f.dateFormat = p[0].count == 8 ? "MM-dd-yy hh:mma" : "MM-dd-yyyy hh:mma"
            return FileEntry(name: p[3].trimmingCharacters(in: .whitespaces), isDirectory: p[2] == "<DIR>",
                size: Int64(p[2]), modified: f.date(from: p[0] + " " + p[1]))
        }
        return nil
    }
}
