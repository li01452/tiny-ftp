import Foundation

struct TransferState {
    let name: String
    let uploading: Bool
    var fraction: Double? = nil
    var label: String { (uploading ? "正在上传：" : "正在下载：") + name }
}

// A single token spans listing fallbacks and the transfer itself.
// Cancellation before Process.run() is remembered, so it cannot accidentally start later.
final class CurlCancellation: @unchecked Sendable {
    private let lock = NSLock()
    private var process: Process?
    private var cancelled = false

    func launch(_ value: Process) throws {
        lock.lock()
        defer { lock.unlock() }
        if cancelled { throw CancellationError() }
        try value.run()
        process = value
    }
    func cancel() {
        lock.lock()
        cancelled = true
        if let process, process.isRunning { process.terminate() }
        lock.unlock()
    }
    func finish() {
        lock.lock(); process = nil; lock.unlock()
    }
    func check() throws {
        lock.lock(); let value = cancelled; lock.unlock()
        if value { throw CancellationError() }
    }
}
