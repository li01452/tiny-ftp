import Foundation

struct FileEntry: Identifiable, Hashable {
    var id: String { name }
    let name: String
    let isDirectory: Bool
    let size: Int64?
    let modified: Date?
    var isSymbolicLink = false

    var sizeText: String {
        if isDirectory { return "—" }
        guard let size else { return "未知" }
        return ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }
    var dateText: String {
        modified?.formatted(date: .numeric, time: .shortened) ?? "—"
    }
    static func sorted(_ entries: [FileEntry]) -> [FileEntry] {
        entries.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }
    static func validName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." &&
        !name.contains("/") && !name.unicodeScalars.contains { $0.value < 32 || $0.value == 127 }
    }
}

enum FTPError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        switch self { case .message(let value): return value }
    }
}

struct FTPEndpoint {
    let origin: String
    let initialPath: [String]

    init(_ input: String) throws {
        var text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        if !text.contains("://") { text = "ftp://" + text }
        guard let c = URLComponents(string: text), c.scheme?.lowercased() == "ftp",
              let host = c.host, !host.isEmpty, c.user == nil, c.password == nil,
              c.query == nil, c.fragment == nil,
              c.port == nil || (1...65535).contains(c.port!) else {
            throw FTPError.message("请输入有效 FTP 地址，例如 ftp://192.168.31.6:2121")
        }
        let components = c.percentEncodedPath.split(separator: "/").map(String.init)
        initialPath = try components.map {
            guard let name = $0.removingPercentEncoding, FileEntry.validName(name) else {
                throw FTPError.message("地址包含无效路径；#、% 等文件名字符需使用 URL 编码。")
            }
            return name
        }
        var base = URLComponents()
        base.scheme = "ftp"
        base.host = host
        base.port = c.port ?? 2121
        guard let value = base.string else { throw FTPError.message("FTP 地址无效") }
        origin = value
    }

    func url(path: [String], file: String? = nil) -> String {
        let safe = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")
        let segments = (path + (file.map { [$0] } ?? [])).map {
            $0.addingPercentEncoding(withAllowedCharacters: safe)!
        }
        return origin + "/" + segments.joined(separator: "/") + (file == nil && !segments.isEmpty ? "/" : "")
    }
}
