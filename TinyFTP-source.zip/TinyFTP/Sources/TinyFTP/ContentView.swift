import AppKit
import SwiftUI

@MainActor
struct ContentView: View {
    @StateObject private var model = FileManagerViewModel()

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "network").foregroundStyle(.secondary)
                TextField("ftp://192.168.31.6:2121", text: $model.address)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit { model.connect() }
                    .disabled(model.busy)
                    .accessibilityLabel("FTP 地址")
                Button("连接") { model.connect() }.disabled(model.busy)
                    .keyboardShortcut(.return, modifiers: .command)
                Button { model.refreshRemote() } label: { Image(systemName: "arrow.clockwise") }
                    .help("刷新远程目录").disabled(model.busy)
                HStack(spacing: 5) {
                    Circle().fill(model.connected ? Color.green : Color.secondary).frame(width: 7, height: 7)
                    Text(model.connectionLabel).font(.caption).foregroundStyle(.secondary)
                }.frame(width: 65)
            }.padding(14)
            Divider()
            HSplitView {
                pane(remote: true).frame(minWidth: 330)
                pane(remote: false).frame(minWidth: 330)
            }
            Divider()
            HStack(spacing: 12) {
                Button { model.download() } label: { Label("下载 →", systemImage: "arrow.down.circle") }
                    .disabled(!model.canDownload)
                Button { model.upload() } label: { Label("← 上传", systemImage: "arrow.up.circle") }
                    .disabled(!model.canUpload)
                Spacer()
                Text("选择一个文件后上传或下载").font(.caption).foregroundStyle(.secondary)
            }.padding(.horizontal, 14).padding(.vertical, 10)
            Divider()
            VStack(alignment: .leading, spacing: 7) {
                if let transfer = model.transfer {
                    HStack {
                        Text(transfer.label).lineLimit(1).truncationMode(.middle)
                        Spacer()
                        Text(transfer.fraction.map { "\(Int($0 * 100))%" } ?? "准备中…")
                            .monospacedDigit().foregroundStyle(.secondary)
                        Button("取消") { model.cancel() }
                    }
                    if let value = transfer.fraction { ProgressView(value: value) }
                    else { ProgressView().progressViewStyle(.linear) }
                } else if model.busy {
                    HStack {
                        ProgressView().controlSize(.small)
                        Text(model.status).lineLimit(1)
                        Spacer()
                        Button("取消") { model.cancel() }
                    }
                }
                if !model.busy || model.transfer != nil {
                    Text(model.status).font(.caption).foregroundStyle(.secondary)
                        .lineLimit(2).textSelection(.enabled)
                }
            }.padding(12).frame(minHeight: 45, alignment: .leading)
        }
        .frame(minWidth: 760, minHeight: 480)
        .alert("操作失败", isPresented: Binding(get: { model.errorMessage != nil }, set: { if !$0 { model.errorMessage = nil } })) {
            Button("好", role: .cancel) { model.errorMessage = nil }
        } message: { Text(model.errorMessage ?? "") }
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.willTerminateNotification)) { _ in model.shutdown() }
    }

    private func pane(remote: Bool) -> some View {
        VStack(spacing: 0) {
            HStack {
                Label(remote ? "FTP 服务器" : "本地文件", systemImage: remote ? "externaldrive.connected.to.line.below" : "laptopcomputer")
                    .font(.headline)
                Spacer()
                Button {
                    if remote { model.remoteUp() } else { model.localUp() }
                } label: { Image(systemName: "arrow.up") }
                    .disabled(model.busy || (remote ? !model.connected || model.remotePath.isEmpty : model.localDirectory.path == "/"))
                    .help("上级目录")
                Button {
                    if remote { model.refreshRemote() } else { model.refreshLocal() }
                } label: { Image(systemName: "arrow.clockwise") }.disabled(model.busy).help("刷新目录")
                if !remote { Button("选择目录…") { model.chooseLocalDirectory() }.disabled(model.busy) }
            }.padding(12)
            HStack {
                Text(remote ? model.remoteLocation : model.localDirectory.path)
                    .font(.caption).foregroundStyle(.secondary).lineLimit(1).truncationMode(.middle)
                    .textSelection(.enabled)
                Spacer(minLength: 0)
            }.padding(.horizontal, 12).padding(.bottom, 9)
            Divider()
            FileTable(entries: remote ? model.remoteEntries : model.localEntries,
                      selection: remote ? $model.remoteSelection : $model.localSelection,
                      open: { entry in if remote { model.openRemote(entry) } else { model.openLocal(entry) } })
                .disabled(model.busy)
            Divider()
            HStack {
                Text("\((remote ? model.remoteEntries : model.localEntries).count) 个项目")
                Spacer()
                if let entry = remote ? model.selectedRemote : model.selectedLocal, entry.isDirectory, !entry.isSymbolicLink {
                    Button("打开文件夹") { if remote { model.openRemote(entry) } else { model.openLocal(entry) } }
                        .disabled(model.busy)
                }
            }.font(.caption).foregroundStyle(.secondary).padding(.horizontal, 12).frame(height: 32)
        }
    }
}

@MainActor
private struct FileTable: View {
    let entries: [FileEntry]
    @Binding var selection: String?
    let open: (FileEntry) -> Void

    var body: some View {
        Table(entries, selection: $selection) {
            TableColumn("名称") { entry in
                HStack(spacing: 7) {
                    Image(systemName: entry.isSymbolicLink ? "link" : (entry.isDirectory ? "folder.fill" : "doc"))
                        .foregroundStyle(entry.isDirectory ? Color.accentColor : Color.secondary)
                    Text(entry.name).lineLimit(1)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
                .onTapGesture(count: 2) { open(entry) }
                .contextMenu {
                    if entry.isDirectory && !entry.isSymbolicLink { Button("打开文件夹") { open(entry) } }
                    Button("复制名称") {
                        NSPasteboard.general.clearContents()
                        NSPasteboard.general.setString(entry.name, forType: .string)
                    }
                }
            }.width(min: 130, ideal: 220)
            TableColumn("修改时间") { entry in Text(entry.dateText).foregroundStyle(.secondary).font(.caption) }
                .width(min: 110, ideal: 130)
            TableColumn("大小") { entry in Text(entry.sizeText).foregroundStyle(.secondary).font(.caption) }
                .width(min: 60, ideal: 75)
        }
    }
}
