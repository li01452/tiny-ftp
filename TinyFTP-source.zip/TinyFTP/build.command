#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export MACOSX_DEPLOYMENT_TARGET=13.0
if ! xcrun --find swiftc >/dev/null 2>&1; then
    echo "需要先安装 Apple Command Line Tools。请在终端执行 xcode-select --install，安装后重新运行本脚本。"
    exit 1
fi
ARCH="$(uname -m)"
SDK="$(xcrun --sdk macosx --show-sdk-path)"
APP="$PWD/dist/Tiny FTP.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
SOURCES=()
while IFS= read -r -d '' SOURCE; do SOURCES+=("$SOURCE"); done < <(find Sources/TinyFTP -name '*.swift' -print0)
xcrun swiftc -swift-version 5 -O -whole-module-optimization -parse-as-library \
    -sdk "$SDK" -target "$ARCH-apple-macosx13.0" \
    -framework SwiftUI -framework AppKit \
    "${SOURCES[@]}" -o "$APP/Contents/MacOS/TinyFTP"
cp Info.plist "$APP/Contents/Info.plist"
/usr/bin/strip -x "$APP/Contents/MacOS/TinyFTP"
/usr/bin/codesign --force --sign - "$APP"
BYTES=$(du -sk "$APP" | awk '{print $1 * 1024}')
echo "构建完成：$APP"
echo "应用占用约 $BYTES 字节（本机架构：$ARCH）"
if (( BYTES > 5000000 )); then echo "提示：本次构建超过 5 MB 体积目标。"; fi
if [[ "${CI:-}" != "true" ]]; then
    /usr/bin/open -R "$APP"
fi
