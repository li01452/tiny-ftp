import XCTest
@testable import TinyFTP

final class DirectoryParserTests: XCTestCase {
    func testMLSDUnicodeSpacesAndFacts() throws {
        let input = "type=cdir;modify=20261017080000; .\r\ntype=pdir; ..\r\ntype=file;size=123;modify=20261017080000; 中文 # 100% [1].txt\r\ntype=dir;modify=20261017080000; 相册\r\n"
        let entries = try DirectoryParser.parse(Data(input.utf8), mlsd: true)
        XCTAssertEqual(entries.map(\.name), ["相册", "中文 # 100% [1].txt"])
        XCTAssertEqual(entries[1].size, 123)
        XCTAssertNotNil(entries[1].modified)
    }
    func testLISTPreservesLeadingAndTrailingFilenameSpaces() throws {
        let input = "total 2\r\ndrwxr-xr-x 1 owner group 0 Oct 17 2026 相册\r\n-rw-r--r-- 1 owner group 12 Oct 17 21:50  文件 空格 .txt \r\n"
        let entries = try DirectoryParser.parse(Data(input.utf8), mlsd: false)
        XCTAssertEqual(entries[1].name, " 文件 空格 .txt ")
        XCTAssertEqual(entries[1].size, 12)
        XCTAssertNotNil(entries[1].modified)
    }
    func testRejectsAmbiguousOrMalformedListings() {
        XCTAssertThrowsError(try DirectoryParser.parse(Data([0xff]), mlsd: true))
        XCTAssertThrowsError(try DirectoryParser.parse(Data("bad format".utf8), mlsd: false))
        XCTAssertThrowsError(try DirectoryParser.parse(Data("type=file; a\ntype=file; a".utf8), mlsd: true))
        XCTAssertThrowsError(try DirectoryParser.parse(Data("type=file; a/b".utf8), mlsd: true))
    }
    func testLISTSymlinksAreMarked() throws {
        let entries = try DirectoryParser.parse(Data("lrwxrwxrwx 1 owner group 3 Oct 17 2026 link -> target\n".utf8), mlsd: false)
        XCTAssertEqual(entries.first?.name, "link")
        XCTAssertEqual(entries.first?.isSymbolicLink, true)
    }
    func testDOSListing() throws {
        let input = "10-17-26  09:50PM       <DIR>          folder\r\n10-17-26  09:50PM                   12 file.txt\r\n"
        let entries = try DirectoryParser.parse(Data(input.utf8), mlsd: false)
        XCTAssertEqual(entries.map(\.name), ["folder", "file.txt"])
        XCTAssertEqual(entries[1].size, 12)
    }
    func testEndpointEscapesPathSegments() throws {
        let endpoint = try FTPEndpoint("192.168.31.6")
        XCTAssertEqual(endpoint.url(path: []), "ftp://192.168.31.6:2121/")
        XCTAssertEqual(endpoint.url(path: ["相册"], file: "a #?%[].txt"),
            "ftp://192.168.31.6:2121/%E7%9B%B8%E5%86%8C/a%20%23%3F%25%5B%5D.txt")
        let nested = try FTPEndpoint("ftp://192.168.31.6:2121/a%20b/")
        XCTAssertEqual(nested.initialPath, ["a b"])
    }
    func testEndpointRejectsOtherProtocolsCredentialsAndTraversal() {
        for input in ["https://example.com", "ftp://user:pass@example.com", "ftp://example.com/%2e%2e/", "ftp://example.com/a%2fb", "ftp://example.com:0", "ftp://example.com/?x=1"] {
            XCTAssertThrowsError(try FTPEndpoint(input), input)
        }
    }
    func testCancelBeforeLaunch() async {
        let token = CurlCancellation(); token.cancel()
        do {
            _ = try await CurlRunner().run(["--url", "ftp://127.0.0.1:1/"], token: token)
            XCTFail("Cancelled process was launched")
        } catch is CancellationError { }
        catch { XCTFail("Expected cancellation, got \(error)") }
    }
    func testSwiftIntegrationAgainstFixture() async throws {
        guard let address = ProcessInfo.processInfo.environment["TINYFTP_TEST_URL"] else {
            throw XCTSkip("Run verification/ftp_smoke.py --swift on macOS for the live Swift integration tests")
        }
        let endpoint = try FTPEndpoint(address)
        let ftp = FTPService()
        let token = CurlCancellation()
        let files = try await ftp.list(endpoint: endpoint, path: [], token: token)
        XCTAssertTrue(files.contains { $0.name == "相册 空格" && $0.isDirectory })
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let source = directory.appendingPathComponent("Swift 中文 #%?[].txt")
        let payload = Data("Swift → FTP → Swift\n".utf8)
        try payload.write(to: source)
        try await ftp.upload(endpoint: endpoint, path: ["相册 空格"], source: source, name: source.lastPathComponent, token: token, progress: { _ in })
        let downloaded = directory.appendingPathComponent("roundtrip")
        try await ftp.download(endpoint: endpoint, path: ["相册 空格"], name: source.lastPathComponent, temporary: downloaded, token: token, progress: { _ in })
        XCTAssertEqual(try Data(contentsOf: downloaded), payload)
        let cancellation = CurlCancellation()
        let task = Task {
            try await ftp.download(endpoint: endpoint, path: [], name: "slow.bin", temporary: directory.appendingPathComponent("partial"), token: cancellation, progress: { _ in })
        }
        try await Task.sleep(nanoseconds: 300_000_000)
        cancellation.cancel()
        do { try await task.value; XCTFail("Transfer was not cancelled") }
        catch is CancellationError { }
        catch { XCTFail("Expected cancellation, got \(error)") }
    }
}
