#!/usr/bin/env python3
"""Dependency-free FTP fixture and curl integration checks. --swift runs Swift tests on macOS too."""
import argparse
import contextlib
import json
import os
from pathlib import Path
import re
import socket
import socketserver
import subprocess
import tempfile
import threading
import time
from urllib.parse import quote

PROJECT = Path(__file__).resolve().parents[1]

class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True
    reject_mlsd = False

class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        self.cwd = self.server.root
        self.listener = None
        self.reply('220 TinyFTP test fixture')
        try:
            while True:
                line = self.rfile.readline().decode('utf-8').rstrip('\r\n')
                if not line:
                    return
                command, _, arg = line.partition(' ')
                command = command.upper()
                if command == 'USER': self.reply('331 Password required')
                elif command == 'PASS': self.reply('230 Logged in')
                elif command == 'PWD': self.reply('257 "/"')
                elif command in ('TYPE', 'OPTS', 'NOOP'): self.reply('200 OK')
                elif command == 'FEAT': self.reply('211 No extensions')
                elif command == 'SYST': self.reply('215 UNIX Type: L8')
                elif command == 'CWD':
                    path = self.path(arg)
                    if path.is_dir(): self.cwd = path; self.reply('250 OK')
                    else: self.reply('550 No such directory')
                elif command in ('EPSV', 'PASV'):
                    if self.listener: self.listener.close()
                    self.listener = socket.socket()
                    self.listener.bind(('127.0.0.1', 0))
                    self.listener.listen(1)
                    self.listener.settimeout(5)
                    port = self.listener.getsockname()[1]
                    self.reply(f'229 Entering Extended Passive Mode (|||{port}|)' if command == 'EPSV' else
                               f'227 Entering Passive Mode (127,0,0,1,{port//256},{port%256})')
                elif command == 'SIZE':
                    path = self.path(arg)
                    self.reply(f'213 {path.stat().st_size}' if path.is_file() else '550 No file')
                elif command == 'MDTM': self.reply('213 20261017080000')
                elif command in ('MLSD', 'LIST', 'RETR', 'STOR'):
                    if command == 'MLSD' and self.server.reject_mlsd:
                        self.reply('500 MLSD unsupported')
                        continue
                    path = self.path(arg) if arg else self.cwd
                    if command == 'RETR' and not path.is_file():
                        self.reply('550 No file'); continue
                    self.reply('150 Data connection')
                    conn, _ = self.listener.accept()
                    with conn:
                        if command in ('MLSD', 'LIST'):
                            items = []
                            for file in sorted(path.iterdir()):
                                size = file.stat().st_size
                                if command == 'MLSD':
                                    items.append(f'type={"dir" if file.is_dir() else "file"};size={size};modify=20261017080000; {file.name}\r\n')
                                else:
                                    items.append(f'{"d" if file.is_dir() else "-"}rwxr-xr-x 1 owner group {size} Oct 17 2026 {file.name}\r\n')
                            conn.sendall(''.join(items).encode('utf-8'))
                        elif command == 'STOR':
                            with path.open('wb') as file:
                                while data := conn.recv(65536): file.write(data)
                        else:
                            with path.open('rb') as file:
                                while data := file.read(16384):
                                    conn.sendall(data)
                                    if path.name == 'slow.bin': time.sleep(.025)
                    self.reply('226 Transfer complete')
                elif command == 'QUIT': self.reply('221 Bye'); return
                else: self.reply('502 Unsupported')
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        finally:
            if self.listener: self.listener.close()

    def path(self, value):
        # curl already decodes percent escapes before sending FTP commands.
        result = (self.server.root / value.lstrip('/') if value.startswith('/') else self.cwd / value).resolve()
        if not result.is_relative_to(self.server.root): raise ValueError('path escaped fixture')
        return result

    def reply(self, value):
        self.wfile.write((value + '\r\n').encode('utf-8')); self.wfile.flush()


def common_arguments():
    source = (PROJECT / 'Sources/TinyFTP/Services/CurlRunner.swift').read_text()
    literal = re.search(r'process.arguments = (\[.*?\]) \+ arguments', source, re.S).group(1)
    return json.loads(literal)


def run(swift=False):
    with tempfile.TemporaryDirectory() as temp:
        # macOS maps /var to /private/var; compare canonical paths on both sides.
        root = (Path(temp) / 'server').resolve(); root.mkdir()
        (root / '相册 空格').mkdir()
        special = '中文 #100%?[]; 空格.txt'
        payload = '测试 UTF-8\n'.encode() + os.urandom(131072)
        (root / special).write_bytes(payload)
        (root / 'slow.bin').write_bytes(b'x' * 8 * 1024 * 1024)
        with Server(('127.0.0.1', 0), Handler) as server:
            server.root = root
            worker = threading.Thread(target=server.serve_forever, daemon=True); worker.start()
            address = f'ftp://127.0.0.1:{server.server_address[1]}/'
            args = ['/usr/bin/curl'] + common_arguments()
            def curl(*extra, check=True):
                return subprocess.run(args + list(extra), capture_output=True, timeout=15, check=check)
            try:
                result = curl('--silent', '--request', 'MLSD', '--url', address)
                assert special in result.stdout.decode() and 'type=dir;' in result.stdout.decode()
                print('PASS MLSD, anonymous login and UTF-8 listing')
                server.reject_mlsd = True
                result = curl('--silent', '--request', 'MLSD', '--url', address, check=False)
                assert result.returncode in (8, 19, 21), result.returncode
                result = curl('--silent', '--url', address)
                assert special in result.stdout.decode() and 'drwx' in result.stdout.decode()
                print('PASS unsupported MLSD exit code and LIST fallback')
                destination = Path(temp) / 'download.part'
                curl('--progress-bar', '--output', str(destination), '--url', address + quote(special, safe=''))
                assert destination.read_bytes() == payload
                print('PASS download of Chinese, spaces, %, #, ?, [], ; filename; exact bytes')
                source = Path(temp) / special; source.write_bytes(payload)
                uploaded_url = address + quote('相册 空格', safe='') + '/' + quote(special, safe='')
                curl('--progress-bar', '--upload-file', str(source), '--url', uploaded_url)
                assert (root / '相册 空格' / special).read_bytes() == payload
                print('PASS upload into Chinese directory; exact bytes')
                source.write_bytes(b'overwrite')
                curl('--progress-bar', '--upload-file', str(source), '--url', uploaded_url)
                assert (root / '相册 空格' / special).read_bytes() == b'overwrite'
                print('PASS server-side file replacement')
                result = curl('--silent', '--output', str(destination), '--url', address + 'missing.txt', check=False)
                assert result.returncode == 78, result.returncode
                print('PASS nonexistent file returns curl 78')
                partial = Path(temp) / 'cancel.part'
                process = subprocess.Popen(args + ['--progress-bar', '--output', str(partial), '--url', address + 'slow.bin'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                time.sleep(.25); process.terminate(); process.communicate(timeout=5)
                assert process.returncode != 0 and 0 < partial.stat().st_size < (root / 'slow.bin').stat().st_size
                print('PASS SIGTERM cancels active transfer')
                meter = Path(temp) / 'progress.part'
                process = subprocess.run(args + ['--progress-bar', '--output', str(meter), '--url', address + 'slow.bin'], capture_output=True, timeout=30)
                assert process.returncode == 0
                values = re.findall(rb'[0-9]+(?:\.[0-9]+)?%', process.stderr)
                assert values and any(float(x[:-1]) >= 99 for x in values), process.stderr[-200:]
                print('PASS curl progress meter contains parseable percentages')
                if swift:
                    environment = dict(os.environ, TINYFTP_TEST_URL=address)
                    subprocess.run(['swift', 'test'], cwd=PROJECT, env=environment, check=True)
            finally:
                server.shutdown(); worker.join(timeout=5)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--swift', action='store_true')
    run(parser.parse_args().swift)
