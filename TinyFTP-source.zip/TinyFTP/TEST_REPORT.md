# 验证记录

验证环境：Linux x86_64；系统 curl 8.5.0；Python 3。未连接用户的局域网或手机。

已执行 `python3 verification/ftp_smoke.py`，8 项均通过：

1. 匿名连接、MLSD 列表和 UTF-8 文件名。
2. MLSD 不支持时的 curl 错误码及 LIST 回退。
3. 中文、空格、%、#、?、[]、; 文件名下载，逐字节比对一致。
4. 上传到中文带空格目录，逐字节比对一致。
5. 同名远程文件替换。
6. 文件不存在返回 curl 78。
7. SIGTERM 中断正在进行的传输。
8. curl 进度输出包含可解析百分比。

上述测试实际执行了 `/usr/bin/curl`，公共参数从 `CurlRunner.swift` 中读取。未在此环境运行 Swift 包装层、Swift 列表解析器或 SwiftUI 界面。

另已检查构建脚本的 bash 语法、Info.plist 格式与工程文件完整性。

工程附带 XCTest，覆盖目录解析、路径编码、无效输入、启动前取消，以及真实 Swift 服务层的上传、下载、列表回退和取消。由于当前环境无 Swift 编译器和 macOS SDK，这些 XCTest 尚未运行。可在 Mac 上执行 `swift test`；执行 `python3 verification/ftp_smoke.py --swift` 可连同本地 FTP 服务一起运行集成测试。

待 Mac 实机确认：Swift 编译、UI 布局与交互、权限提示、应用实际体积、macOS 自带 curl 的行为，以及小米手机服务器的完整兼容性。

已补充 GitHub Actions 网页构建配置和 CI 无界面构建支持。配置已做结构检查；尚未在用户 GitHub 仓库执行。
