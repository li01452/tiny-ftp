# 验证记录

验证环境：Linux x86_64；系统 curl 8.5.0；Python 3。未连接用户的局域网或手机。

已执行 `python3 verification/ftp_smoke.py`，8 项均通过：

1. 匿名连接、MLSD 列表和 UTF-8 文件名。
2. MLSD 不支持时的 curl 错误码及 LIST 回退。
3. 中文、空格、%、#、?、[]、; 文件名下载，逐字节比对一致。
4. 上传到中文带空格目录，逐字节比对一致。
5. 同名远程文件替换。
6. 文件不存在返回 curl 78。
7. SIGTERM 中断正在进行的传输。
8. curl 进度输出包含可解析百分比。

上述测试实际执行了 `/usr/bin/curl`，公共参数从 `CurlRunner.swift` 中读取。未在此环境运行 Swift 包装层、Swift 列表解析器或 SwiftUI 界面。

另已检查构建脚本的 bash 语法、Info.plist 格式与工程文件完整性。

工程附带 XCTest，覆盖目录解析、路径编码、无效输入、启动前取消，以及真实 Swift 服务层的上传、下载、列表回退和取消。由于当前环境无 Swift 编译器和 macOS SDK，这些 XCTest 尚未运行。可在 Mac 上执行 `swift test`；执行 `python3 verification/ftp_smoke.py --swift` 可连同本地 FTP 服务一起运行集成测试。

待 Mac 实机确认：Swift 编译、UI 布局与交互、权限提示、应用实际体积、macOS 自带 curl 的行为，以及小米手机服务器的完整兼容性。

已补充 GitHub Actions 网页构建配置和 CI 无界面构建支持。配置已做结构检查；尚未在用户 GitHub 仓库执行。

## 修复：macOS 临时目录符号链接

用户首次云端测试在 Python FTP 测试服务器中出现 `ValueError: path escaped fixture`。原因是 macOS 的 `/var` 与 `/private/var` 指向同一路径，测试服务器只解析了请求路径的符号链接，未解析根目录。现已对测试根目录统一调用 `resolve()`，保留越界检查。

在 Linux 中创建符号链接临时目录，已复现相同错误；修复后在相同符号链接环境下，8 项 curl 集成检查全部通过。此修复未改动应用传输代码。macOS 上的 Swift 编译及 XCTest 仍待重新运行云端工作流确认。

## 修复：进度测试的时间预算

第二次 macOS 云端运行已通过上传、下载、覆盖、缺失文件、取消等检查，但用于进度测试的人工慢速传输触发 Python 30 秒超时。此前取消测试和进度测试共用 8 MB 慢速文件，并按每 16 KB 休眠 25 毫秒，实际耗时受调度影响。

现将两者拆开：取消测试在发送第一段数据后只暂停一次，并在观察到实际写入后才取消；进度测试改用独立 2 MB 文件，由 curl 限速至 1 MB/s，设置 60 秒超时并校验完整内容。数据连接启用 TCP_NODELAY。不是仅增加原慢速测试的超时。

`--swift` 模式现先执行 `swift build --build-tests`，再运行 FTP 检查，最后 `swift test --skip-build`。原 GitHub 工作流无需修改即可先暴露 Swift 编译错误。

本地验证：普通临时目录及符号链接临时目录下的全部 8 项 curl 检查通过。此环境仍无 macOS SDK，Swift 编译和 XCTest 尚待云端执行。
